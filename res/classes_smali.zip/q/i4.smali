.class public final Lq/i4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Iterator;


# instance fields
.field public final a:I

.field public b:I

.field public c:I

.field public d:Z

.field public final synthetic e:Lq/y;


# direct methods
.method public constructor <init>(Lq/y;I)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lq/i4;->e:Lq/y;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lq/i4;->d:Z

    iput p2, p0, Lq/i4;->a:I

    iget-object p1, p1, Lq/y;->d:Ljava/lang/Object;

    check-cast p1, Lq/z;

    iget p1, p1, Lq/z;->c:I

    iput p1, p0, Lq/i4;->b:I

    return-void
.end method


# virtual methods
.method public final hasNext()Z
    .locals 2

    iget v0, p0, Lq/i4;->c:I

    iget v1, p0, Lq/i4;->b:I

    if-ge v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final next()Ljava/lang/Object;
    .locals 3

    invoke-virtual {p0}, Lq/i4;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    iget v0, p0, Lq/i4;->c:I

    iget-object v1, p0, Lq/i4;->e:Lq/y;

    iget v2, p0, Lq/i4;->a:I

    invoke-virtual {v1, v0, v2}, Lq/y;->a(II)Ljava/lang/Object;

    move-result-object v0

    iget v1, p0, Lq/i4;->c:I

    const/4 v2, 0x1

    add-int/2addr v1, v2

    iput v1, p0, Lq/i4;->c:I

    iput-boolean v2, p0, Lq/i4;->d:Z

    return-object v0

    :cond_0
    new-instance v0, Ljava/util/NoSuchElementException;

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    throw v0
.end method

.method public final remove()V
    .locals 2

    iget-boolean v0, p0, Lq/i4;->d:Z

    if-eqz v0, :cond_0

    iget v0, p0, Lq/i4;->c:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lq/i4;->c:I

    iget v1, p0, Lq/i4;->b:I

    add-int/lit8 v1, v1, -0x1

    iput v1, p0, Lq/i4;->b:I

    const/4 v1, 0x0

    iput-boolean v1, p0, Lq/i4;->d:Z

    iget-object v1, p0, Lq/i4;->e:Lq/y;

    invoke-virtual {v1, v0}, Lq/y;->b(I)V

    return-void

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    throw v0
.end method
