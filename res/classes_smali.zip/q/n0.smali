.class public final Lq/n0;
.super Lq/i3;
.source "SourceFile"


# static fields
.field public static final i:Lq/n0;

.field public static final j:Lq/l0;


# instance fields
.field public d:I

.field public e:I

.field public f:I

.field public g:Lq/O0;

.field public h:B


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lq/n0;

    invoke-direct {v0}, Lq/i3;-><init>()V

    const/4 v1, 0x0

    iput v1, v0, Lq/n0;->e:I

    iput v1, v0, Lq/n0;->f:I

    const/4 v1, -0x1

    iput-byte v1, v0, Lq/n0;->h:B

    sput-object v0, Lq/n0;->i:Lq/n0;

    new-instance v0, Lq/l0;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lq/n0;->j:Lq/l0;

    return-void
.end method


# virtual methods
.method public final A(Lq/h;)Lq/a;
    .locals 1

    new-instance v0, Lq/m0;

    invoke-direct {v0, p1}, Lq/R2;-><init>(Lq/h;)V

    return-object v0
.end method

.method public final C()Lq/O0;
    .locals 1

    iget-object v0, p0, Lq/n0;->g:Lq/O0;

    if-nez v0, :cond_0

    sget-object v0, Lq/O0;->k:Lq/O0;

    :cond_0
    return-object v0
.end method

.method public final D()Z
    .locals 1

    iget v0, p0, Lq/n0;->d:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final E()Z
    .locals 1

    iget v0, p0, Lq/n0;->d:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final F()Z
    .locals 2

    iget v0, p0, Lq/n0;->d:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public final G()Lq/m0;
    .locals 2

    sget-object v0, Lq/n0;->i:Lq/n0;

    const/4 v1, 0x0

    if-ne p0, v0, :cond_0

    new-instance v0, Lq/m0;

    invoke-direct {v0, v1}, Lq/R2;-><init>(Lq/h;)V

    goto :goto_0

    :cond_0
    new-instance v0, Lq/m0;

    invoke-direct {v0, v1}, Lq/R2;-><init>(Lq/h;)V

    invoke-virtual {v0, p0}, Lq/m0;->T(Lq/n0;)V

    :goto_0
    return-object v0
.end method

.method public final c(Lq/g0;)V
    .locals 2

    iget v0, p0, Lq/n0;->d:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_0

    iget v0, p0, Lq/n0;->e:I

    invoke-virtual {p1, v1, v0}, Lq/g0;->P(II)V

    :cond_0
    iget v0, p0, Lq/n0;->d:I

    const/4 v1, 0x2

    and-int/2addr v0, v1

    if-eqz v0, :cond_1

    iget v0, p0, Lq/n0;->f:I

    invoke-virtual {p1, v1, v0}, Lq/g0;->P(II)V

    :cond_1
    iget v0, p0, Lq/n0;->d:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_2

    const/4 v0, 0x3

    invoke-virtual {p0}, Lq/n0;->C()Lq/O0;

    move-result-object v1

    invoke-virtual {p1, v0, v1}, Lq/g0;->R(ILq/o4;)V

    :cond_2
    iget-object v0, p0, Lq/i3;->c:Lq/W5;

    invoke-virtual {v0, p1}, Lq/W5;->c(Lq/g0;)V

    return-void
.end method

.method public final e()I
    .locals 3

    iget v0, p0, Lq/c;->b:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_0

    return v0

    :cond_0
    iget v0, p0, Lq/n0;->d:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_1

    iget v0, p0, Lq/n0;->e:I

    invoke-static {v1, v0}, Lq/g0;->A(II)I

    move-result v0

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    iget v1, p0, Lq/n0;->d:I

    const/4 v2, 0x2

    and-int/2addr v1, v2

    if-eqz v1, :cond_2

    iget v1, p0, Lq/n0;->f:I

    invoke-static {v2, v1}, Lq/g0;->A(II)I

    move-result v1

    add-int/2addr v0, v1

    :cond_2
    iget v1, p0, Lq/n0;->d:I

    and-int/lit8 v1, v1, 0x4

    if-eqz v1, :cond_3

    const/4 v1, 0x3

    invoke-virtual {p0}, Lq/n0;->C()Lq/O0;

    move-result-object v2

    invoke-static {v1, v2}, Lq/g0;->C(ILq/o4;)I

    move-result v1

    add-int/2addr v0, v1

    :cond_3
    iget-object v1, p0, Lq/i3;->c:Lq/W5;

    invoke-virtual {v1}, Lq/W5;->e()I

    move-result v1

    add-int/2addr v1, v0

    iput v1, p0, Lq/c;->b:I

    return v1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p1, p0, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Lq/n0;

    if-nez v1, :cond_1

    invoke-super {p0, p1}, Lq/c;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1

    :cond_1
    check-cast p1, Lq/n0;

    invoke-virtual {p0}, Lq/n0;->F()Z

    move-result v1

    invoke-virtual {p1}, Lq/n0;->F()Z

    move-result v2

    const/4 v3, 0x0

    if-eq v1, v2, :cond_2

    return v3

    :cond_2
    invoke-virtual {p0}, Lq/n0;->F()Z

    move-result v1

    if-eqz v1, :cond_3

    iget v1, p0, Lq/n0;->e:I

    iget v2, p1, Lq/n0;->e:I

    if-eq v1, v2, :cond_3

    return v3

    :cond_3
    invoke-virtual {p0}, Lq/n0;->D()Z

    move-result v1

    invoke-virtual {p1}, Lq/n0;->D()Z

    move-result v2

    if-eq v1, v2, :cond_4

    return v3

    :cond_4
    invoke-virtual {p0}, Lq/n0;->D()Z

    move-result v1

    if-eqz v1, :cond_5

    iget v1, p0, Lq/n0;->f:I

    iget v2, p1, Lq/n0;->f:I

    if-eq v1, v2, :cond_5

    return v3

    :cond_5
    invoke-virtual {p0}, Lq/n0;->E()Z

    move-result v1

    invoke-virtual {p1}, Lq/n0;->E()Z

    move-result v2

    if-eq v1, v2, :cond_6

    return v3

    :cond_6
    invoke-virtual {p0}, Lq/n0;->E()Z

    move-result v1

    if-eqz v1, :cond_7

    invoke-virtual {p0}, Lq/n0;->C()Lq/O0;

    move-result-object v1

    invoke-virtual {p1}, Lq/n0;->C()Lq/O0;

    move-result-object v2

    invoke-virtual {v1, v2}, Lq/O0;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7

    return v3

    :cond_7
    iget-object v1, p0, Lq/i3;->c:Lq/W5;

    iget-object p1, p1, Lq/i3;->c:Lq/W5;

    invoke-virtual {v1, p1}, Lq/W5;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_8

    return v3

    :cond_8
    return v0
.end method

.method public final h()Z
    .locals 3

    iget-byte v0, p0, Lq/n0;->h:B

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    return v1

    :cond_0
    const/4 v2, 0x0

    if-nez v0, :cond_1

    return v2

    :cond_1
    invoke-virtual {p0}, Lq/n0;->E()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Lq/n0;->C()Lq/O0;

    move-result-object v0

    invoke-virtual {v0}, Lq/O0;->h()Z

    move-result v0

    if-nez v0, :cond_2

    iput-byte v2, p0, Lq/n0;->h:B

    return v2

    :cond_2
    iput-byte v1, p0, Lq/n0;->h:B

    return v1
.end method

.method public final hashCode()I
    .locals 4

    iget v0, p0, Lq/c;->a:I

    if-eqz v0, :cond_0

    return v0

    :cond_0
    sget-object v0, Lq/f2;->g:Lq/g2;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    add-int/lit16 v0, v0, 0x30b

    invoke-virtual {p0}, Lq/n0;->F()Z

    move-result v1

    const/16 v2, 0x35

    if-eqz v1, :cond_1

    const/16 v1, 0x25

    const/4 v3, 0x1

    invoke-static {v0, v1, v3, v2}, Lq/i2;->d(IIII)I

    move-result v0

    iget v1, p0, Lq/n0;->e:I

    add-int/2addr v0, v1

    :cond_1
    invoke-virtual {p0}, Lq/n0;->D()Z

    move-result v1

    if-eqz v1, :cond_2

    const/16 v1, 0x25

    const/4 v3, 0x2

    invoke-static {v0, v1, v3, v2}, Lq/i2;->d(IIII)I

    move-result v0

    iget v1, p0, Lq/n0;->f:I

    add-int/2addr v0, v1

    :cond_2
    invoke-virtual {p0}, Lq/n0;->E()Z

    move-result v1

    if-eqz v1, :cond_3

    const/16 v1, 0x25

    const/4 v3, 0x3

    invoke-static {v0, v1, v3, v2}, Lq/i2;->d(IIII)I

    move-result v0

    invoke-virtual {p0}, Lq/n0;->C()Lq/O0;

    move-result-object v1

    invoke-virtual {v1}, Lq/O0;->hashCode()I

    move-result v1

    add-int/2addr v0, v1

    :cond_3
    mul-int/lit8 v0, v0, 0x1d

    iget-object v1, p0, Lq/i3;->c:Lq/W5;

    invoke-virtual {v1}, Lq/W5;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    iput v1, p0, Lq/c;->a:I

    return v1
.end method

.method public final i()Lq/c;
    .locals 1

    sget-object v0, Lq/n0;->i:Lq/n0;

    return-object v0
.end method

.method public final bridge synthetic j()Lq/n4;
    .locals 1

    invoke-virtual {p0}, Lq/n0;->G()Lq/m0;

    move-result-object v0

    return-object v0
.end method

.method public final p()Lq/a;
    .locals 1

    sget-object v0, Lq/n0;->i:Lq/n0;

    invoke-virtual {v0}, Lq/n0;->G()Lq/m0;

    move-result-object v0

    return-object v0
.end method

.method public final bridge synthetic r()Lq/a;
    .locals 1

    invoke-virtual {p0}, Lq/n0;->G()Lq/m0;

    move-result-object v0

    return-object v0
.end method

.method public final y()Lq/h3;
    .locals 3

    sget-object v0, Lq/f2;->h:Lq/h3;

    const-class v1, Lq/n0;

    const-class v2, Lq/m0;

    invoke-virtual {v0, v1, v2}, Lq/h3;->c(Ljava/lang/Class;Ljava/lang/Class;)V

    return-object v0
.end method
