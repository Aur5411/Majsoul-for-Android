.class public final enum Lq/k7;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum a:Lq/k7;

.field public static final enum b:Lq/k7;

.field public static final enum c:Lq/k7;

.field public static final enum d:Lq/k7;

.field public static final enum e:Lq/k7;

.field public static final enum f:Lq/k7;

.field public static final enum g:Lq/k7;

.field public static final enum h:Lq/k7;

.field public static final enum i:Lq/k7;

.field public static final synthetic j:[Lq/k7;


# direct methods
.method static constructor <clinit>()V
    .locals 12

    new-instance v0, Lq/k7;

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v3, "INT"

    invoke-direct {v0, v3, v1, v2}, Lq/k7;-><init>(Ljava/lang/String;ILjava/io/Serializable;)V

    sput-object v0, Lq/k7;->a:Lq/k7;

    new-instance v1, Lq/k7;

    const-wide/16 v2, 0x0

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const-string v3, "LONG"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4, v2}, Lq/k7;-><init>(Ljava/lang/String;ILjava/io/Serializable;)V

    sput-object v1, Lq/k7;->b:Lq/k7;

    new-instance v2, Lq/k7;

    const/4 v3, 0x0

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    const-string v4, "FLOAT"

    const/4 v5, 0x2

    invoke-direct {v2, v4, v5, v3}, Lq/k7;-><init>(Ljava/lang/String;ILjava/io/Serializable;)V

    sput-object v2, Lq/k7;->c:Lq/k7;

    new-instance v3, Lq/k7;

    const-wide/16 v4, 0x0

    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    const-string v5, "DOUBLE"

    const/4 v6, 0x3

    invoke-direct {v3, v5, v6, v4}, Lq/k7;-><init>(Ljava/lang/String;ILjava/io/Serializable;)V

    sput-object v3, Lq/k7;->d:Lq/k7;

    new-instance v4, Lq/k7;

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const-string v6, "BOOLEAN"

    const/4 v7, 0x4

    invoke-direct {v4, v6, v7, v5}, Lq/k7;-><init>(Ljava/lang/String;ILjava/io/Serializable;)V

    sput-object v4, Lq/k7;->e:Lq/k7;

    new-instance v5, Lq/k7;

    const-string v6, ""

    const-string v7, "STRING"

    const/4 v8, 0x5

    invoke-direct {v5, v7, v8, v6}, Lq/k7;-><init>(Ljava/lang/String;ILjava/io/Serializable;)V

    sput-object v5, Lq/k7;->f:Lq/k7;

    new-instance v6, Lq/k7;

    sget-object v7, Lq/c0;->c:Lq/c0;

    const-string v8, "BYTE_STRING"

    const/4 v9, 0x6

    invoke-direct {v6, v8, v9, v7}, Lq/k7;-><init>(Ljava/lang/String;ILjava/io/Serializable;)V

    sput-object v6, Lq/k7;->g:Lq/k7;

    new-instance v7, Lq/k7;

    const-string v8, "ENUM"

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-direct {v7, v8, v9, v10}, Lq/k7;-><init>(Ljava/lang/String;ILjava/io/Serializable;)V

    sput-object v7, Lq/k7;->h:Lq/k7;

    new-instance v8, Lq/k7;

    const-string v9, "MESSAGE"

    const/16 v11, 0x8

    invoke-direct {v8, v9, v11, v10}, Lq/k7;-><init>(Ljava/lang/String;ILjava/io/Serializable;)V

    sput-object v8, Lq/k7;->i:Lq/k7;

    filled-new-array/range {v0 .. v8}, [Lq/k7;

    move-result-object v0

    sput-object v0, Lq/k7;->j:[Lq/k7;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/io/Serializable;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lq/k7;
    .locals 1

    const-class v0, Lq/k7;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lq/k7;

    return-object p0
.end method

.method public static values()[Lq/k7;
    .locals 1

    sget-object v0, Lq/k7;->j:[Lq/k7;

    invoke-virtual {v0}, [Lq/k7;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lq/k7;

    return-object v0
.end method
