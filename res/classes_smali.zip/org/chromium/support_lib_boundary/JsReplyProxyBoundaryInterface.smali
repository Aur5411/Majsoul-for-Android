.class public interface abstract Lorg/chromium/support_lib_boundary/JsReplyProxyBoundaryInterface;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lorg/chromium/support_lib_boundary/IsomorphicObjectBoundaryInterface;


# virtual methods
.method public abstract executeJavaScript(Ljava/lang/String;Ljava/lang/reflect/InvocationHandler;)V
.end method

.method public abstract postMessage(Ljava/lang/String;)V
.end method

.method public abstract postMessageWithPayload(Ljava/lang/reflect/InvocationHandler;)V
.end method
