.class public interface abstract Lorg/chromium/support_lib_boundary/WebResourceErrorBoundaryInterface;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract getDebugCode()I
.end method

.method public abstract getDescription()Ljava/lang/CharSequence;
.end method

.method public abstract getErrorCode()I
.end method
